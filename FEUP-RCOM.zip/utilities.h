#ifndef UTILITIES_H_
#define UTILITIES_H_

void startCounter();

double getTransferRate(int numBytes);

double getDeltaTime();

void initCounter();

#endif